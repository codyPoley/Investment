#include "AirGeadInvestment.h"
#include <iostream>
#include <iomanip>
#include <conio.h>

using namespace std;

AirGeadInvestment::AirGeadInvestment() { //set default class
	m_InvestmentAmount = 0.0; //set default investment
	m_DepositAmount = 0.0; //set default deposit
	m_InterestPercent = 0; //set default interest
	m_HowManyYears = 0; //set default year amount
	
}

AirGeadInvestment::AirGeadInvestment(double investment, double deposit, int annualInterest, int numOfYears) {
	m_InvestmentAmount = investment; //set user investment
	m_DepositAmount = deposit; //set user deposit
	m_InterestPercent = annualInterest; //set user interest
	m_HowManyYears = numOfYears; //set user years investment
	return;
}



double AirGeadInvestment::GetInvestment() const{
	return m_InvestmentAmount; //get user investment
}

double AirGeadInvestment::GetDeposit() const {
	return m_DepositAmount; //get user deposit
}

int AirGeadInvestment::GetInterest() const {
	return m_InterestPercent; //get user percentage
}

int AirGeadInvestment::GetNumOfYears() const {
	return m_HowManyYears; //get user years
}

void AirGeadInvestment::DisplayMenu(AirGeadInvestment* account) { //display menu 

	if (account == nullptr) { //if account empty
		cout << "***************************************************************" << endl;
		cout << "********************** Data Input *****************************" << endl;
		cout << "Intitial Investment Amount:" << endl;
		cout << "Monthly Deposit:" << endl;
		cout << "Annual Interest:" << endl;
		cout << "Number of years:" << endl;
	}
	else { //if account not empty
		cout << "***************************************************************" << endl;
		cout << "********************** Data Input *****************************" << endl;
		cout << "Intitial Investment Amount:  $" << fixed << setprecision(2) << account->GetInvestment() << endl;
		cout << "Monthly Deposit:  $" << account->GetDeposit() << endl;
		cout << "Annual Interest:  %" << account->GetInterest() << endl;
		cout << "Number of years: " << account->GetNumOfYears() << endl;
	}
	cout << "Press any key to continue . . ." << endl;
	while (!(_kbhit())) {} //wait for key press
	cout << endl;
}

AirGeadInvestment* AirGeadInvestment::InsertInvestment(AirGeadInvestment* account) {
	double investment = 0.0; //hold investment amount 
	double deposit = 0.0; //hold deposit amount
	int annualInterest = 0; //hold interest rate
	int numOfYears = 0; //hold how many years of interest


	cout << "Enter Intitial Investment Amount:  $"; //ask for investment
	cin >> investment; //get investment

	while (cin.fail()) {
		cin.clear();
		cin.ignore();
		cout << "Not a valid investment. Please enter in investment amount: ";
		cin >> investment;
	}

	cout << "Enter Monthly Deposit:  $"; //ask for deposit
	cin >> deposit; //get deposit

	while (cin.fail()) {
		cin.clear();
		cin.ignore();
		cout << "Not a valid deposit. Please enter in deposit amount: ";
		cin >> deposit;
	}

	cout << "Enter Annual Interest:  %"; //ask for interest percentage
	cin >> annualInterest; //get interest percentage

	while (cin.fail()) {
		cin.clear();
		cin.ignore();
		cout << "Not a valid annual interest. Please enter in annual interest amount: ";
		cin >> annualInterest;
	}

	cout << "Enter Number of years: "; //ask for years
	cin >> numOfYears; //get years

	while (cin.fail()) {
		cin.clear();
		cin.ignore();
		cout << "Not a valid number of years. Please enter in number of years amount: ";
		cin >> numOfYears;
	}

	account = new AirGeadInvestment(investment, deposit, annualInterest, numOfYears); //set all information to account
	return account; //send account back to main
}

void AirGeadInvestment::ResultsOfInvestment(AirGeadInvestment* account) {
	double investmentHolder = account->GetInvestment(); //set with investment
	double investmentDepositHolder = account->GetInvestment() + (account->GetDeposit() * 12); //set with investment plus deposit * 12
	double yearEndBalance = investmentHolder; //set to first investment
	double yearEndWithDeposit = investmentDepositHolder; //set to investmentDepositHolder
	int interestHolder = account->GetInterest(); //set to first interest amount
	double interestRate = (double)interestHolder / 100; //set interestRate to decimal
	double startAmount = account->GetInvestment(); //get starting amount

	cout << "         Balance and Interest without Additional Monthly Deposits" << endl;
	cout << "=========================================================================" << endl;
	cout << "  Year            Year End Balance            Year End Earned Interest" << endl;
	cout << "-------------------------------------------------------------------------" << endl;

	for (int i = 1; i < account->GetNumOfYears() + 1; i++) { //loop tell i = years
		double interestOverYear = yearEndBalance * interestRate; //get interestRate
		yearEndBalance += interestOverYear; //add interest to final balance
		cout << "     " << i << "               $" << fixed << setprecision(2) << yearEndBalance << "                          $" << interestOverYear << "\n\n";
	}

	cout << endl;

	cout << "            Balance and Interest with Additional Monthly Deposits" << endl;
	cout << "=========================================================================" << endl;
	cout << "  Year            Year End Balance            Year End Earned Interest" << endl;
	cout << "-------------------------------------------------------------------------" << endl;

	for (int i = 1; i < account->GetNumOfYears() + 1; i++) { //loop tell i = years
		double interestHolder = 0; //set to 0
		double interestDrop = 0; //set to 0
		for (int x = 0; x < 12; x++) { //loop tell x = 11 
			startAmount += account->GetDeposit(); //get deposit amount 
			interestDrop = (startAmount) * ((interestRate) / 12); //get interest
			startAmount += interestDrop; //add interest to total
			interestHolder += interestDrop; //save the amount of interest
		}

		yearEndWithDeposit = startAmount; //save final amount
		cout << "     " << i << "               $" << fixed << setprecision(2) << yearEndWithDeposit << "                          $" << interestHolder << "\n\n";
	}
}
