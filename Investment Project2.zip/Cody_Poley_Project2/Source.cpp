#include <iostream>
#include <iomanip>
#include <conio.h>
#include <stdexcept>
#include "AirGeadInvestment.h"

using namespace std;

int main() {
	int exit = 1; //set exit to 1

	while (exit != 2) { //loop tell user enters 2
		AirGeadInvestment* firstAccount = nullptr; //set firstAccount to nullptr

		firstAccount->DisplayMenu(firstAccount); //display menu
		firstAccount = firstAccount->InsertInvestment(firstAccount); //enter information
		firstAccount->DisplayMenu(firstAccount); //display menu with entered information
		firstAccount->ResultsOfInvestment(firstAccount); //show the results
		
		cout << "Enter 1 If You Would Like To Try Another Investment or 2 To Exit The Program:"; //ask the user if they want to continue
		cin >> exit; //get users choice
	}

}