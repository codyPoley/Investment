
using namespace std;

class AirGeadInvestment{
public:
	AirGeadInvestment();
	AirGeadInvestment(double investment, double deposit, int annualInterest, int numOfYears);
	double GetInvestment() const;
	double GetDeposit() const;
	int GetInterest() const;
	int GetNumOfYears() const;
	void DisplayMenu(AirGeadInvestment* account);
	AirGeadInvestment* InsertInvestment(AirGeadInvestment* account);
	void ResultsOfInvestment(AirGeadInvestment* account);

private:
	double m_InvestmentAmount;
	double m_DepositAmount;
	int m_InterestPercent;
	int m_HowManyYears;
};
